import os from 'node:os';
import fs from 'node:fs/promises';
import { config } from './config.js';
import { db, recordError, resolveLatestError } from './db.js';
import { info, warn } from './logger.js';
import { telegramTokenHealth } from './telegram-api.js';

async function fetchOk(url, options = {}, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    return response.ok;
  } finally {
    clearTimeout(timer);
  }
}

function saveCheck(component, healthy, detail, action = '') {
  db.prepare('INSERT INTO health_checks(component, healthy, detail, action) VALUES (?, ?, ?, ?)')
    .run(component, healthy ? 1 : 0, String(detail).slice(0, 1000), action);
}

export async function checkGateway() {
  try {
    const healthy = await fetchOk(`${config.gatewayUrl.replace(/\/$/, '')}/`);
    saveCheck('gateway', healthy, healthy ? 'HTTP OK' : 'Gateway returned an error');
    if (healthy) resolveLatestError('gateway', 'Gateway health restored');
    return healthy;
  } catch (caught) {
    saveCheck('gateway', false, caught.message, 'Alert operator; external supervisor should restart gateway');
    recordError('gateway', 'GATEWAY_DOWN', caught.message, {}, 'External supervisor restart');
    warn('watchdog', `gateway down: ${caught.message}`);
    return false;
  }
}

export async function checkInternet() {
  try {
    const healthy = await fetchOk('https://cloudflare.com/cdn-cgi/trace', {}, 7000);
    saveCheck('internet', healthy, healthy ? 'Cloudflare reachable' : 'Cloudflare error');
    if (healthy) resolveLatestError('internet', 'Connectivity restored');
    return healthy;
  } catch (caught) {
    saveCheck('internet', false, caught.message, 'Retry with exponential backoff');
    recordError('internet', caught.name === 'AbortError' ? 'NETWORK_TIMEOUT' : (caught.code || 'NETWORK_DOWN'), caught.message, {}, 'Exponential retry');
    return false;
  }
}

export async function checkTelegram() {
  if (!config.telegramToken) {
    saveCheck('telegram', true, 'Disabled because TELEGRAM_BOT_TOKEN is empty', 'Add token to enable alerts');
    return true;
  }
  try {
    const healthy = await telegramTokenHealth(config.telegramToken);
    const outgoing = db.prepare(`
      SELECT status, COUNT(*) AS count FROM telegram_outgoing
      WHERE created_at >= datetime('now', '-24 hours') GROUP BY status
    ` ).all().map(item => `${item.status}=${item.count}`).join(',') || 'empty';
    saveCheck('telegram', healthy, healthy ? `Bot token valid; outbox(${outgoing})` : 'Telegram rejected token or proxy unavailable');
    if (healthy) resolveLatestError('telegram', 'Telegram token working');
    return healthy;
  } catch (caught) {
    saveCheck('telegram', false, caught.message, 'Check token/network');
    recordError('telegram', caught.code || 'TELEGRAM_DOWN', caught.message, {}, 'Check token/network');
    return false;
  }
}

export async function checkAiProvider() {
  if (!config.openRouterKey || process.env.AI_PROVIDER === 'local') {
    const reason = process.env.AI_PROVIDER === 'local' ? 'وضع المحاكاة الذكية مطلوب' : 'لا يوجد مفتاح سحابي';
    saveCheck('ai', true, `${reason}; deterministic local generation active`, 'Add a valid OPENROUTER_API_KEY or GEMINI_API_KEY for cloud generation');
    return true;
  }
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 7000);
    const response = await fetch('https://openrouter.ai/api/v1/models', {
      headers: { authorization: `Bearer ${config.openRouterKey}` },
      signal: controller.signal
    });
    clearTimeout(timer);
    if (response.ok) {
      saveCheck('ai', true, 'OpenRouter reachable');
      resolveLatestError('ai', 'OpenRouter reachable');
      return true;
    }
    if ([401, 402, 403].includes(response.status)) {
      saveCheck('ai', true, `تم رفض المفتاح السحابي؛ المحاكاة الذكية الآمنة نشطة`, 'Replace OPENROUTER_API_KEY');
      recordError('ai', 'AI_KEY_REJECTED', `OpenRouter returned ${response.status}`, {}, 'Safe local fallback activated');
      return true;
    }
    saveCheck('ai', false, `OpenRouter HTTP ${response.status}`, 'Retry with backoff');
    recordError('ai', 'AI_HTTP', `OpenRouter returned ${response.status}`, {}, 'Retry with backoff');
    return false;
  } catch (caught) {
    saveCheck('ai', false, caught.message, 'Switch provider or apply backoff');
    recordError('ai', caught.name === 'AbortError' ? 'AI_TIMEOUT' : (caught.code || 'AI_DOWN'), caught.message, {}, 'Backoff and switch provider');
    return false;
  }
}

export function checkResources() {
  const freeMemoryMb = Math.round(os.freemem() / 1024 / 1024);
  const memoryHealthy = freeMemoryMb > 100;
  saveCheck('memory', memoryHealthy, `${freeMemoryMb} MB free`, memoryHealthy ? '' : 'Pause heavy jobs');
  return memoryHealthy;
}

export async function checkDisk() {
  try {
    const stats = await fs.statfs(config.root);
    const freeMb = Math.round((stats.bavail * stats.bsize) / 1024 / 1024);
    const healthy = freeMb > 200;
    saveCheck('disk', healthy, `${freeMb} MB free`, healthy ? '' : 'Clean old logs/backups');
    return healthy;
  } catch (caught) {
    saveCheck('disk', false, caught.message, '');
    return false;
  }
}

export async function runWatchdog() {
  const results = {
    gateway: await checkGateway(),
    internet: await checkInternet(),
    telegram: await checkTelegram(),
    ai: await checkAiProvider(),
    memory: checkResources(),
    disk: await checkDisk()
  };
  info('watchdog', 'health cycle complete', results);
  return results;
}
