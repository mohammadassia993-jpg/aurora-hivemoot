import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import { config } from './config.js';
import { db } from './db.js';
import { activateTeam, planTask, executeTask, reviewTask, requestApproval } from './agents.js';
import { runConnectors } from './connectors.js';
import { runWeeklyResearch } from './research.js';
import { runWatchdog } from './watchdog.js';
import { dailyReport, handleTelegramUpdate, processTelegramOutbox, sendMessage, telegramMode } from './telegram.js';
import { modelPerformance } from './ai.js';
import { mailQueueStats, sendMail } from './mail.js';
import { readPublicLink } from './tunnel.js';
import { audit } from './audit.js';
import { recordError } from './db.js';
import { dashboardData } from './dashboard.js';
import { performancePlan } from './performance.js';
import { AGENTS, listMessages, createMessage, attachmentFile } from './team.js';

const mimeTypes = {
  '.html': 'text/html; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.pdf': 'application/pdf', '.zip': 'application/zip', '.mp4': 'video/mp4',
  '.mov': 'video/quicktime', '.webm': 'video/webm', '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8', '.csv': 'text/csv; charset=utf-8', '.json': 'application/json'
};

async function readBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 35 * 1024 * 1024) throw Object.assign(new Error('request too large'), { code: 'REQUEST_TOO_LARGE' });
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString();
  return raw ? JSON.parse(raw) : {};
}

async function readRawBody(request, limit = 80 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error('database backup too large'), { code: 'BACKUP_TOO_LARGE' });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function json(response, status, payload) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  response.end(JSON.stringify(payload, null, 2));
}

function isLoopback(request) {
  if (request.headers['x-forwarded-for'] || request.headers['cf-connecting-ip'] || request.headers['x-real-ip']) return false;
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.socket.remoteAddress || '');
}

function authorized(request, url) {
  const supplied = url.searchParams.get('key') || request.headers['x-team-key'] || '';
  const expected = Buffer.from(config.teamUiToken);
  const actual = Buffer.from(String(supplied));
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function databaseSyncAuthorized(request) {
  const expected = Buffer.from(config.databaseSyncToken || '');
  const actual = Buffer.from(String(request.headers['x-database-sync-key'] || ''));
  return expected.length > 0 && actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

async function serveFile(response, absolutePath, downloadName = '') {
  const content = await fs.readFile(absolutePath);
  const ext = path.extname(absolutePath).toLowerCase();
  response.writeHead(200, {
    'content-type': mimeTypes[ext] || 'application/octet-stream',
    'content-length': content.length,
    ...(downloadName ? { 'content-disposition': `attachment; filename="${encodeURIComponent(downloadName)}"` } : {})
  });
  response.end(content);
}

export async function startServer() {
  const server = http.createServer(async (request, response) => {
    const url = new URL(request.url, `http://${request.headers.host}`);
    try {
      if (url.pathname === '/health') {
        const latest = db.prepare(`
          SELECT component, healthy FROM health_checks
          WHERE id IN (SELECT MAX(id) FROM health_checks GROUP BY component)
          AND created_at >= datetime('now', '-120 seconds')
        `).all();
        const health = Object.fromEntries(latest.map(row => [row.component, Boolean(row.healthy)]));
        const complete = ['gateway', 'internet', 'telegram', 'ai', 'memory', 'disk'].every(name => name in health);
        if (complete) {
          const ok = Object.values(health).every(Boolean);
          return json(response, ok ? 200 : 503, { ok, health, source: 'cached' });
        }
        const checked = await runWatchdog();
        const ok = Object.values(checked).every(Boolean);
        return json(response, ok ? 200 : 503, { ok, health: checked, source: 'live' });
      }

      if (url.pathname === '/status') {
        return json(response, 200, {
          telegram: { mode: telegramMode(), tokenValidated: Boolean(config.telegramToken), webhookConfigured: Boolean(process.env.TELEGRAM_WEBHOOK_URL) },
          backup: { url: config.backupUrl },
          tasksByStatus: db.prepare('SELECT status, COUNT(*) AS count FROM tasks GROUP BY status').all(),
          openErrors: db.prepare("SELECT scope, error_type, message FROM errors WHERE resolved = 0 ORDER BY id DESC LIMIT 20").all(),
          pendingApprovals: db.prepare("SELECT * FROM approvals WHERE state = 'pending'").all(),
          models: modelPerformance()
        });
      }

      if (url.pathname === '/telegram/webhook' && request.method === 'POST') {
        const secret = request.headers['x-telegram-bot-api-secret-token'] || '';
        if (!config.telegramWebhookSecret || secret !== config.telegramWebhookSecret) {
          return json(response, 401, { ok: false });
        }
        const update = await readBody(request);
        let outbox = { processed: 0 };
        try {
          await handleTelegramUpdate(update);
          outbox = await processTelegramOutbox();
        } catch (caught) {
          recordError('telegram', 'WEBHOOK_HANDLER_ERROR', caught.message);
        }
        return json(response, 200, { ok: true, outbox });
      }

      if (url.pathname === '/api/sync/database' && request.method === 'POST') {
        if (config.platformRole !== 'render' || !config.databaseSyncToken || !databaseSyncAuthorized(request)) {
          return json(response, 403, { ok: false, error: 'database sync disabled or unauthorized' });
        }
        const payload = await readRawBody(request);
        const expectedHash = String(request.headers['x-sha256'] || '');
        const actualHash = crypto.createHash('sha256').update(payload).digest('hex');
        if (!payload.subarray(0, 16).equals(Buffer.from('SQLite format 3\0'))) {
          return json(response, 400, { ok: false, error: 'invalid SQLite database' });
        }
        if (expectedHash && expectedHash !== actualHash) {
          return json(response, 400, { ok: false, error: 'backup checksum mismatch' });
        }
        await fs.mkdir(path.join(config.root, 'data'), { recursive: true });
        const target = path.join(config.root, 'data', 'incoming-platform.db');
        await fs.writeFile(target, payload);
        audit('aurora', 'database_backup_received', { bytes: payload.byteLength, sha256: actualHash });
        if (process.env.ALLOW_DATABASE_RESTORE_RESTART === 'true') {
          setTimeout(() => process.exit(0), 1000).unref();
        }
        return json(response, 202, { ok: true, accepted: true, sha256: actualHash, restoreOnRestart: true });
      }

      const publicShell = ['/', '/dashboard', '/app'].includes(url.pathname);
      const localReport = url.pathname === '/report' && isLoopback(request);
      if (!publicShell && !localReport && !authorized(request, url)) return json(response, 401, { error: 'team key required' });

      if (url.pathname === '/tasks') {
        return json(response, 200, { tasks: db.prepare('SELECT * FROM tasks ORDER BY fit_score DESC, id DESC LIMIT 100').all() });
      }

      if (url.pathname === '/report') {
        const health = await runWatchdog();
        const dashboard = await dashboardData();
        const tunnel = await readPublicLink();
        let finalReport = '';
        try {
          finalReport = await fs.readFile(path.join(config.root, 'data', 'final-report.txt'), 'utf8');
        } catch {}
        return json(response, 200, {
          generatedAt: new Date().toISOString(),
          status: Object.values(health).every(Boolean) ? 'running' : 'degraded',
          health,
          services: {
            platform: true,
            gateway: health.gateway,
            ai: health.ai,
            database: health.memory && health.disk,
            internet: health.internet,
            telegram: Boolean(config.telegramToken),
            telegramMode: telegramMode(),
            dework: config.deworkToken ? 'live' : 'simulation',
            titan: config.titanUrl ? 'live' : 'simulation',
            emailQueue: mailQueueStats(),
            tunnel: { provider: 'pinggy', url: tunnel.url || '', updatedAt: tunnel.updatedAt || '' },
            renderBackup: config.backupUrl,
            koyeb: { bundleReady: true, live: false }
          },
          agents: dashboard.agents,
          projects: dashboard.projects,
          finance: dashboard.finance,
          links: { ...dashboard.links, backup: config.backupUrl, report: `http://127.0.0.1:${config.port}/report` },
          dailyReport: dailyReport(),
          finalReport
        });
      }

      if (url.pathname === '/agents/activate' && request.method === 'POST') {
        return json(response, 200, { activation: await activateTeam() });
      }

      if (url.pathname === '/api/dashboard') {
        const data = await dashboardData();
        data.performance = performancePlan();
        if (config.publicBaseUrl) {
          data.links.public = `${config.publicBaseUrl}/?key=${encodeURIComponent(config.teamUiToken)}`;
        }
        return json(response, 200, data);
      }

      if (url.pathname === '/api/team/agents') return json(response, 200, { agents: (await dashboardData()).agents });

      if (url.pathname === '/api/team/messages' && request.method === 'GET') {
        return json(response, 200, { messages: listMessages(url.searchParams.get('limit')) });
      }

      if (url.pathname === '/api/team/messages' && request.method === 'POST') {
        const body = await readBody(request);
        const saved = await createMessage(body);
        return json(response, 201, { message: saved });
      }

      if (url.pathname === '/api/notifications' && request.method === 'GET') {
        const rows = db.prepare(`
          SELECT id,kind,title,body,read,created_at AS createdAt
          FROM notifications ORDER BY id DESC LIMIT 100
        `).all();
        const unread = db.prepare('SELECT COUNT(*) AS count FROM notifications WHERE read=0').get().count;
        return json(response, 200, { notifications: rows, unread });
      }

      if (url.pathname === '/api/notifications/read' && request.method === 'POST') {
        db.prepare('UPDATE notifications SET read=1 WHERE read=0').run();
        return json(response, 200, { ok: true });
      }

      if (url.pathname.startsWith('/uploads/') && request.method === 'GET') {
        const relative = decodeURIComponent(url.pathname);
        const file = await attachmentFile(relative);
        if (!file) return json(response, 404, { error: 'attachment not found' });
        response.writeHead(200, { 'content-type': mimeTypes[path.extname(relative).toLowerCase()] || 'application/octet-stream' });
        return response.end(file);
      }

      if (url.pathname === '/research/weekly' && request.method === 'POST') {
        return json(response, 200, { report: await runWeeklyResearch() });
      }

      if (url.pathname === '/emergency' && request.method === 'POST') {
        const body = await readBody(request);
        const message = body.message || 'Emergency activation requested.';
        recordError('emergency', 'EMERGENCY_REQUEST', message, body, 'Activate backup and notify operator');
        audit('aurora', 'emergency_request', { message });
        const telegramResult = await sendMessage(`🚨 Aurora emergency request\n${message}`);
        const mailResult = await sendMail({
          to: config.officialEmail,
          subject: 'Aurora emergency activation',
          text: `${message}\n\nDashboard: http://127.0.0.1:${config.port}\nBackup URL: ${config.backupUrl || 'not configured'}`
        });
        return json(response, 202, { accepted: true, telegram: telegramResult, email: mailResult });
      }

      if (url.pathname === '/sync' && request.method === 'POST') {
        return json(response, 200, { connectors: await runConnectors() });
      }

      let match;
      if ((match = url.pathname.match(/^\/tasks\/(\d+)\/(plan|execute|review)$/)) && request.method === 'POST') {
        const taskId = Number(match[1]);
        const output = match[2] === 'plan' ? await planTask(taskId) : match[2] === 'execute' ? await executeTask(taskId) : await reviewTask(taskId);
        return json(response, 200, { output });
      }

      if ((match = url.pathname.match(/^\/tasks\/(\d+)\/submit$/)) && request.method === 'POST') {
        const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(Number(match[1]));
        if (!task) return json(response, 404, { error: 'task not found' });
        if (task.status !== 'ready_for_approval') return json(response, 409, { error: 'task is not ready for submission' });
        if (config.contractApprovalRequired) {
          const approval = requestApproval(task.id, 'submission');
          return json(response, 202, { approval_id: Number(approval.lastInsertRowid), state: 'pending_human_approval' });
        }
        db.prepare("UPDATE tasks SET status = 'submitted', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(task.id);
        return json(response, 200, { state: 'submitted' });
      }

      if (['/', '/dashboard'].includes(url.pathname) || url.pathname === '/app') {
        let html = await fs.readFile(path.join(config.root, 'public', 'index.html'), 'utf8');
        html = html.replace("localStorage.getItem('teamKey')||'__TEAM_KEY__'", `localStorage.getItem('teamKey')||'${isLoopback(request) ? config.teamUiToken : ''}'`);
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
        return response.end(html);
      }

      if (url.pathname.startsWith('/icons/') && !url.pathname.includes('..')) {
        const iconPath = path.resolve(config.root, 'public', '.' + url.pathname);
        if (iconPath.startsWith(path.join(config.root, 'public', 'icons'))) {
          await serveFile(response, iconPath);
          return;
        }
      }

      return json(response, 404, { error: 'not found' });
    } catch (caught) {
      console.error(caught);
      return json(response, caught.code === 'ATTACHMENT_SIZE' || caught.code === 'REQUEST_TOO_LARGE' ? 413 : 500, { error: caught.message });
    }
  });

  await new Promise(resolve => server.listen(config.port, '0.0.0.0', resolve));
  return server;
}
