#!/bin/sh
set -u
ROOT="${SILENT_GIANTS_ROOT:-$HOME/silent-giants}"
LOG="$ROOT/logs/watchdog.log"
URL="http://127.0.0.1:${PORT:-8787}/health"
mkdir -p "$ROOT/logs"
termux-wake-lock >/dev/null 2>&1 || true
failures=0
while true; do
  if curl -fsS --max-time 12 "$URL" >/dev/null 2>&1; then
    failures=0
  else
    failures=$((failures + 1))
    echo "$(date -Is) health failed ($failures)" >> "$LOG"
    if [ "$failures" -ge 2 ]; then
      OLD_PID=$(cat "$ROOT/platform.pid" 2>/dev/null || true)
      if [ -n "$OLD_PID" ] && [ -d "/proc/$OLD_PID" ]; then kill "$OLD_PID" 2>/dev/null || true; fi
      rm -f "$ROOT/platform.pid"
      cd "$ROOT" || exit
      PORT="${PORT:-8787}" setsid nohup node src/index.js >> "$ROOT/logs/stdout.log" 2>&1 < /dev/null &
      NEW_PID=$!
      echo "$NEW_PID" > "$ROOT/platform.pid"
      echo "$(date -Is) started recovery platform pid=$NEW_PID" >> "$LOG"
      failures=0
    fi
  fi
  sleep 30
done
